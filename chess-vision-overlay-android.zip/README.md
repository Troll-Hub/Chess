# Chess Vision Overlay (Android)

App Android que captura la pantalla con MediaProjection y muestra una flecha
transparente con la mejor jugada encima del juego.

Estado actual:
- Permiso de superposición y de captura: listo.
- Captura continua de pantalla en servicio en primer plano: listo.
- Overlay transparente que no bloquea los toques: listo.
- Detección del tablero y de piezas (`BoardAnalyzer`): pendiente.
- Motor Stockfish nativo (`BestMoveProvider`): pendiente.

Uso: abre la app, concede "Mostrar sobre otras apps", inicia la captura y
acepta el aviso del sistema.

Compilación: en GitHub Actions (artefacto `chess-vision-overlay-debug-apk`) o
en Android Studio abriendo la carpeta `android/`.
