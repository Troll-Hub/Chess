package com.example.chessvision

/**
 * Motor de jugadas. Pendiente: integrar Stockfish nativo (UCI).
 * Devuelve la jugada en formato UCI, por ejemplo "e2e4", o null si no hay.
 */
interface BestMoveProvider {
    fun bestMove(fen: String): String?
}

class StubEngine : BestMoveProvider {
    override fun bestMove(fen: String): String? = null
}
