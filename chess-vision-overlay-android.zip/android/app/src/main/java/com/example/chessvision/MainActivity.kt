package com.example.chessvision

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(intent)
            status.text = "Captura activa. Abre tu juego."
        } else {
            status.text = "Permiso de captura denegado."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply { text = "Listo. Sigue los pasos en orden." }

        val overlayBtn = Button(this).apply {
            text = "1. Permitir superposición"
            setOnClickListener { requestOverlay() }
        }
        val captureBtn = Button(this).apply {
            text = "2. Iniciar captura"
            setOnClickListener { requestCapture() }
        }
        val stopBtn = Button(this).apply {
            text = "Detener"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Detenido."
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(overlayBtn)
            addView(captureBtn)
            addView(stopBtn)
        }
        setContentView(root)
    }

    private fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            status.text = "Superposición ya permitida."
            return
        }
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Primero concede la superposición."
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
