package com.example.chessvision

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Paint
import android.view.View
import android.view.WindowManager

/** Gestiona la capa transparente que se dibuja sobre el juego. */
class OverlayController(private val context: Context) {

    private val wm = context.getSystemService(WindowManager::class.java)
    private val view = ArrowView(context)
    private var added = false

    // minSdk 26, así que siempre existe TYPE_APPLICATION_OVERLAY
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )

    fun showMove(boardRect: RectF, move: String) {
        view.setMove(boardRect, move)
        if (!added) {
            wm.addView(view, params)
            added = true
        }
    }

    fun clear() {
        view.setMove(null, null)
    }

    fun remove() {
        if (added) {
            wm.removeView(view)
            added = false
        }
    }
}

/** Dibuja una flecha entre dos casillas. Asume que las blancas están abajo. */
class ArrowView(context: Context) : View(context) {

    private var board: RectF? = null
    private var from: String? = null
    private var to: String? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 0, 200, 80)
        strokeWidth = 14f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    fun setMove(rect: RectF?, move: String?) {
        val valid = move?.takeIf { it.length >= 4 }
        board = rect
        from = valid?.substring(0, 2)
        to = valid?.substring(2, 4)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = board ?: return
        val f = from ?: return
        val t = to ?: return
        val start = squareCenter(b, f)
        val end = squareCenter(b, t)
        canvas.drawLine(start.x, start.y, end.x, end.y, paint)
    }

    private fun squareCenter(b: RectF, sq: String): PointF {
        val file = sq[0] - 'a'
        val rank = sq[1] - '1'
        val size = b.width() / 8f
        return PointF(
            b.left + (file + 0.5f) * size,
            b.top + (7 - rank + 0.5f) * size
        )
    }
}
