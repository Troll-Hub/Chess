package com.example.chessvision

import android.graphics.Bitmap
import android.graphics.RectF

data class BoardResult(val fen: String, val boardRect: RectF)

/**
 * Pendiente: localizar el tablero en la captura y clasificar cada pieza.
 * Devuelve null mientras no esté implementado.
 */
class BoardAnalyzer {
    fun analyze(frame: Bitmap): BoardResult? = null
}
